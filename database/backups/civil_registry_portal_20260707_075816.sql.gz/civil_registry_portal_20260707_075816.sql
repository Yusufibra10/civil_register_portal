-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: civil_registry_portal
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_logs_user_date` (`user_id`,`created_at`),
  KEY `idx_logs_date` (`created_at`),
  KEY `idx_logs_action_date` (`action`,`created_at`),
  CONSTRAINT `fk_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (1,2,'LOGIN','auth','Registry Officer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:28'),(2,2,'CREATE_CITIZEN','citizens','Registered Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:28'),(3,2,'CREATE_BIRTH_CERTIFICATE','birth','Registered a birth certificate for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:29'),(4,2,'CREATE_APPLICATION','applications','Submitted a National ID application for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:29'),(5,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"received\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:30'),(6,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"in_review\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:31'),(7,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"approved\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:32'),(8,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"card_printed\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:32'),(9,2,'LOGOUT','auth','User logged out.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:12:33'),(10,2,'LOGIN','auth','Registry Officer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:17:23'),(11,2,'LOGIN','auth','Registry Officer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:27'),(12,2,'CREATE_CITIZEN','citizens','Registered Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:28'),(13,2,'CREATE_BIRTH_CERTIFICATE','birth','Registered a birth certificate for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:28'),(14,2,'CREATE_APPLICATION','applications','Submitted a National ID application for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:29'),(15,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"received\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:30'),(16,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"in_review\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:31'),(17,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"approved\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:31'),(18,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"card_printed\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:32'),(19,2,'LOGOUT','auth','User logged out.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:19:33'),(20,2,'LOGIN','auth','Registry Officer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:55'),(21,2,'CREATE_CITIZEN','citizens','Registered Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:55'),(22,2,'CREATE_BIRTH_CERTIFICATE','birth','Registered a birth certificate for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:56'),(23,2,'CREATE_APPLICATION','applications','Submitted a National ID application for Amina Warsame.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:56'),(24,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"received\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:57'),(25,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"in_review\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:58'),(26,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"approved\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:58'),(27,2,'UPDATE_APPLICATION_STATUS','applications','Moved application to \"card_printed\".','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:20:59'),(28,2,'LOGOUT','auth','User logged out.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-06 16:21:00'),(29,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:27:03'),(30,1,'LOGOUT','auth','User logged out.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:29:12'),(31,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:29:35'),(32,1,'CREATE_CITIZEN','citizens','Registered yuusuf axmed.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:32:47'),(33,1,'CREATE_BIRTH_CERTIFICATE','birth','Registered a birth certificate for yuusuf axmed.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:34:10'),(34,1,'CREATE_APPLICATION','applications','Submitted a National ID application for yuusuf axmed.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:35:32'),(35,1,'ASSIGN_APPLICATION','applications','Assigned application to self.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-07-06 16:35:37'),(36,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:20'),(37,1,'CREATE_USER','users','Created user Test Officer (testofficer761562@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:21'),(38,1,'TOGGLE_USER_STATUS','users','Set Test Officer to inactive.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:22'),(39,1,'TOGGLE_USER_STATUS','users','Set Test Officer to active.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:22'),(40,1,'UPDATE_USER','users','Updated user Test Officer (testofficer761562@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:22'),(41,1,'DELETE_USER','users','Deleted user Test Officer (testofficer761562@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:23'),(42,1,'RESTORE_USER','users','Restored user Test Officer (testofficer761562@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:24'),(43,3,'LOGIN','auth','Records Viewer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:55'),(44,3,'ACCESS_DENIED','permission_middleware','Attempted to access a page without the required permission (users.view).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 03:59:56'),(45,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:34'),(46,1,'CREATE_USER','users','Created user Test Officer (testofficer895254@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:35'),(47,1,'TOGGLE_USER_STATUS','users','Set Test Officer to inactive.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:35'),(48,1,'TOGGLE_USER_STATUS','users','Set Test Officer to active.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:36'),(49,1,'UPDATE_USER','users','Updated user Test Officer (testofficer895254@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:36'),(50,1,'DELETE_USER','users','Deleted user Test Officer (testofficer895254@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:37'),(51,1,'RESTORE_USER','users','Restored user Test Officer (testofficer895254@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:37'),(52,1,'CREATE_ROLE','roles','Created role Auditor Reviewer with 2 permission(s).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:38'),(53,1,'UPDATE_SETTINGS','settings','Updated system settings.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:39'),(54,1,'EXPORT_REPORT','reports','Applications Report exported as CSV (4 rows).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:01:39'),(55,3,'LOGIN','auth','Records Viewer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:02:12'),(56,3,'ACCESS_DENIED','permission_middleware','Attempted to access a page without the required permission (users.view).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:02:12'),(57,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:21'),(58,1,'CREATE_USER','users','Created user Test Officer (testofficer061758@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:21'),(59,1,'TOGGLE_USER_STATUS','users','Set Test Officer to inactive.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:22'),(60,1,'TOGGLE_USER_STATUS','users','Set Test Officer to active.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:22'),(61,1,'UPDATE_USER','users','Updated user Test Officer (testofficer061758@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:22'),(62,1,'DELETE_USER','users','Deleted user Test Officer (testofficer061758@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:23'),(63,1,'RESTORE_USER','users','Restored user Test Officer (testofficer061758@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:23'),(64,3,'LOGIN','auth','Records Viewer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:55'),(65,3,'ACCESS_DENIED','permission_middleware','Attempted to access a page without the required permission (users.view).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:04:55'),(66,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:49'),(67,1,'CREATE_USER','users','Created user Test Officer (testofficer150055@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:50'),(68,1,'TOGGLE_USER_STATUS','users','Set Test Officer to inactive.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:50'),(69,1,'TOGGLE_USER_STATUS','users','Set Test Officer to active.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:50'),(70,1,'UPDATE_USER','users','Updated user Test Officer (testofficer150055@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:51'),(71,1,'DELETE_USER','users','Deleted user Test Officer (testofficer150055@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:51'),(72,1,'RESTORE_USER','users','Restored user Test Officer (testofficer150055@example.com).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:52'),(73,1,'CREATE_ROLE','roles','Created role Auditor Gamma with 2 permission(s).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:52'),(74,1,'UPDATE_SETTINGS','settings','Updated system settings.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:53'),(75,1,'EXPORT_REPORT','reports','Applications Report exported as CSV (4 rows).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:54'),(76,1,'EXPORT_REPORT','reports','Applications Report exported as PDF (4 rows).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:54'),(77,1,'DOWNLOAD_REPORT','reports','Applications Report re-downloaded.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:55'),(78,3,'LOGIN','auth','Records Viewer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:56'),(79,3,'ACCESS_DENIED','permission_middleware','Attempted to access a page without the required permission (users.view).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:05:56'),(80,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:11'),(81,3,'LOGIN','auth','Records Viewer logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:14'),(82,3,'ACCESS_DENIED','permission_middleware','Attempted to access a page without the required permission (users.view).','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:15'),(83,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:15'),(84,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(85,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(86,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(87,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(88,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(89,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(90,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(91,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(92,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(93,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(94,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(95,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(96,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:16'),(97,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(98,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(99,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(100,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(101,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(102,NULL,'CERT_VERIFY','birth','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(103,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:17'),(104,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(105,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(106,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(107,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(108,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(109,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(110,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(111,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(112,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:18'),(113,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(114,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(115,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(116,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(117,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(118,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(119,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(120,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(121,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(122,NULL,'APP_TRACK','applications','::1','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:19'),(123,NULL,'LOGIN_FAILED','auth','nonexistent_attacker_test@example.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:20'),(124,NULL,'LOGIN_FAILED','auth','nonexistent_attacker_test@example.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:21'),(125,NULL,'LOGIN_FAILED','auth','nonexistent_attacker_test@example.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:21'),(126,NULL,'LOGIN_FAILED','auth','nonexistent_attacker_test@example.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:21'),(127,NULL,'LOGIN_FAILED','auth','nonexistent_attacker_test@example.com','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:21'),(128,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:37:23'),(129,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:43:19'),(130,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:43:25'),(131,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:43:31'),(132,1,'LOGIN','auth','System Administrator logged in.','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-07-07 04:43:41'),(133,1,'LOGIN','auth','System Administrator logged in.','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-07-07 04:43:47'),(134,1,'LOGIN','auth','System Administrator logged in.','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-07-07 04:43:53'),(135,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15','2026-07-07 04:44:00'),(136,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15','2026-07-07 04:44:06'),(137,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15','2026-07-07 04:44:11'),(138,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:45:27'),(139,1,'LOGIN','auth','System Administrator logged in.','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/149.0.7827.55 Safari/537.36','2026-07-07 04:56:00');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_status`
--

DROP TABLE IF EXISTS `application_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_status` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `label` varchar(50) NOT NULL,
  `sort_order` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_status_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_status`
--

LOCK TABLES `application_status` WRITE;
/*!40000 ALTER TABLE `application_status` DISABLE KEYS */;
INSERT INTO `application_status` VALUES (1,'submitted','Submitted',1),(2,'received','Received',2),(3,'in_review','Under Review',3),(4,'approved','Approved',4),(5,'rejected','Rejected',5),(6,'card_printed','Card Printed',6),(7,'ready_for_collection','Ready for Collection',7);
/*!40000 ALTER TABLE `application_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `birth_certificates`
--

DROP TABLE IF EXISTS `birth_certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `birth_certificates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_number` varchar(30) NOT NULL,
  `citizen_id` bigint(20) unsigned NOT NULL,
  `father_citizen_id` bigint(20) unsigned DEFAULT NULL,
  `father_full_name` varchar(150) DEFAULT NULL,
  `father_national_id` varchar(20) DEFAULT NULL,
  `mother_citizen_id` bigint(20) unsigned DEFAULT NULL,
  `mother_full_name` varchar(150) DEFAULT NULL,
  `mother_national_id` varchar(20) DEFAULT NULL,
  `registration_date` date NOT NULL,
  `place_of_registration` varchar(150) DEFAULT NULL,
  `issued_by` int(10) unsigned DEFAULT NULL,
  `status` enum('active','revoked') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bc_certificate_number` (`certificate_number`),
  UNIQUE KEY `uq_bc_citizen` (`citizen_id`),
  KEY `idx_bc_registration_date` (`registration_date`),
  KEY `idx_bc_status` (`status`),
  KEY `fk_bc_father` (`father_citizen_id`),
  KEY `fk_bc_mother` (`mother_citizen_id`),
  KEY `fk_bc_issued_by` (`issued_by`),
  CONSTRAINT `fk_bc_citizen` FOREIGN KEY (`citizen_id`) REFERENCES `citizens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_bc_father` FOREIGN KEY (`father_citizen_id`) REFERENCES `citizens` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_bc_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_bc_mother` FOREIGN KEY (`mother_citizen_id`) REFERENCES `citizens` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `birth_certificates`
--

LOCK TABLES `birth_certificates` WRITE;
/*!40000 ALTER TABLE `birth_certificates` DISABLE KEYS */;
INSERT INTO `birth_certificates` VALUES (1,'BC-2026-3167',1,NULL,NULL,NULL,NULL,NULL,NULL,'2024-03-20','Hargeisa Civil Registry Office',2,'active','2026-07-06 16:12:29','2026-07-06 16:12:29'),(2,'BC-2026-8105',2,NULL,NULL,NULL,NULL,NULL,NULL,'2024-03-20','Hargeisa Civil Registry Office',2,'active','2026-07-06 16:19:28','2026-07-06 16:19:28'),(3,'BC-2026-8184',3,NULL,NULL,NULL,NULL,NULL,NULL,'2024-03-20','Hargeisa Civil Registry Office',2,'active','2026-07-06 16:20:56','2026-07-06 16:20:56'),(4,'BC-2026-1309',4,NULL,'ibrahmin axmed warsame','38733',NULL,'canab yusuf ducaale','22332','2026-07-06',NULL,1,'active','2026-07-06 16:34:10','2026-07-06 16:34:10');
/*!40000 ALTER TABLE `birth_certificates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizens`
--

DROP TABLE IF EXISTS `citizens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `citizen_uid` varchar(20) NOT NULL,
  `national_id_number` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `date_of_birth` date NOT NULL,
  `place_of_birth` varchar(150) NOT NULL,
  `marital_status` enum('Single','Married','Divorced','Widowed') DEFAULT NULL,
  `nationality` varchar(100) NOT NULL DEFAULT 'Somaliland',
  `occupation` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `registration_date` date NOT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_citizens_uid` (`citizen_uid`),
  UNIQUE KEY `uq_citizens_national_id` (`national_id_number`),
  UNIQUE KEY `uq_citizens_email` (`email`),
  KEY `idx_citizens_name` (`last_name`,`first_name`),
  KEY `idx_citizens_dob` (`date_of_birth`),
  KEY `idx_citizens_region_district` (`region`,`district`),
  KEY `idx_citizens_status` (`status`),
  KEY `fk_citizens_created_by` (`created_by`),
  CONSTRAINT `fk_citizens_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizens`
--

LOCK TABLES `citizens` WRITE;
/*!40000 ALTER TABLE `citizens` DISABLE KEYS */;
INSERT INTO `citizens` VALUES (1,'CIT-2026-4389',NULL,'Amina',NULL,'Warsame','Female','2024-03-15','Hargeisa',NULL,'Somaliland',NULL,'63348536',NULL,NULL,NULL,NULL,NULL,'active','2026-07-06',NULL,2,'2026-07-06 16:12:28','2026-07-06 16:12:28',NULL),(2,'CIT-2026-6429',NULL,'Amina',NULL,'Warsame','Female','2024-03-15','Hargeisa',NULL,'Somaliland',NULL,'63768332',NULL,NULL,NULL,NULL,NULL,'active','2026-07-06',NULL,2,'2026-07-06 16:19:28','2026-07-06 16:19:28',NULL),(3,'CIT-2026-9490',NULL,'Amina',NULL,'Warsame','Female','2024-03-15','Hargeisa',NULL,'Somaliland',NULL,'63855616',NULL,NULL,NULL,NULL,NULL,'active','2026-07-06',NULL,2,'2026-07-06 16:20:55','2026-07-06 16:20:55',NULL),(4,'CIT-2026-0156',NULL,'yuusuf','ibraahim','axmed','Male','2006-01-01','hargisa','Single','Somaliland',NULL,'+252 63 4596888','yusufiB@gmail.com','masallaha','maroodi-jeex',NULL,NULL,'active','2026-07-06',NULL,1,'2026-07-06 16:32:47','2026-07-06 16:32:47',NULL);
/*!40000 ALTER TABLE `citizens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `citizen_id` bigint(20) unsigned DEFAULT NULL,
  `birth_certificate_id` bigint(20) unsigned DEFAULT NULL,
  `id_application_id` bigint(20) unsigned DEFAULT NULL,
  `document_type` varchar(50) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_by` int(10) unsigned DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_doc_citizen` (`citizen_id`),
  KEY `idx_doc_bc` (`birth_certificate_id`),
  KEY `idx_doc_app` (`id_application_id`),
  KEY `fk_doc_uploaded_by` (`uploaded_by`),
  CONSTRAINT `fk_doc_app` FOREIGN KEY (`id_application_id`) REFERENCES `id_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_doc_bc` FOREIGN KEY (`birth_certificate_id`) REFERENCES `birth_certificates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_doc_citizen` FOREIGN KEY (`citizen_id`) REFERENCES `citizens` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_doc_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `chk_doc_single_owner` CHECK ((`citizen_id` is not null) + (`birth_certificate_id` is not null) + (`id_application_id` is not null) = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `id_application_status_history`
--

DROP TABLE IF EXISTS `id_application_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_application_status_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint(20) unsigned NOT NULL,
  `status_id` tinyint(3) unsigned NOT NULL,
  `changed_by` int(10) unsigned DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ash_application` (`application_id`,`changed_at`),
  KEY `fk_ash_status` (`status_id`),
  KEY `fk_ash_changed_by` (`changed_by`),
  CONSTRAINT `fk_ash_application` FOREIGN KEY (`application_id`) REFERENCES `id_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ash_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ash_status` FOREIGN KEY (`status_id`) REFERENCES `application_status` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_application_status_history`
--

LOCK TABLES `id_application_status_history` WRITE;
/*!40000 ALTER TABLE `id_application_status_history` DISABLE KEYS */;
INSERT INTO `id_application_status_history` VALUES (1,1,1,2,'Application submitted.','2026-07-06 16:12:29'),(2,1,2,2,NULL,'2026-07-06 16:12:30'),(3,1,3,2,NULL,'2026-07-06 16:12:31'),(4,1,4,2,NULL,'2026-07-06 16:12:32'),(5,1,6,2,NULL,'2026-07-06 16:12:32'),(6,2,1,2,'Application submitted.','2026-07-06 16:19:29'),(7,2,2,2,NULL,'2026-07-06 16:19:30'),(8,2,3,2,NULL,'2026-07-06 16:19:31'),(9,2,4,2,NULL,'2026-07-06 16:19:31'),(10,2,6,2,NULL,'2026-07-06 16:19:32'),(11,3,1,2,'Application submitted.','2026-07-06 16:20:56'),(12,3,2,2,NULL,'2026-07-06 16:20:57'),(13,3,3,2,NULL,'2026-07-06 16:20:58'),(14,3,4,2,NULL,'2026-07-06 16:20:58'),(15,3,6,2,NULL,'2026-07-06 16:20:59'),(16,4,1,1,'Application submitted.','2026-07-06 16:35:32');
/*!40000 ALTER TABLE `id_application_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `id_applications`
--

DROP TABLE IF EXISTS `id_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_applications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `application_number` varchar(30) NOT NULL,
  `citizen_id` bigint(20) unsigned NOT NULL,
  `current_status_id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `applied_date` date NOT NULL,
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_app_number` (`application_number`),
  KEY `idx_app_status_date` (`current_status_id`,`applied_date`),
  KEY `idx_app_citizen` (`citizen_id`),
  KEY `fk_app_assigned_to` (`assigned_to`),
  CONSTRAINT `fk_app_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_app_citizen` FOREIGN KEY (`citizen_id`) REFERENCES `citizens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_app_status` FOREIGN KEY (`current_status_id`) REFERENCES `application_status` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `id_applications`
--

LOCK TABLES `id_applications` WRITE;
/*!40000 ALTER TABLE `id_applications` DISABLE KEYS */;
INSERT INTO `id_applications` VALUES (1,'APP-2026-6689',1,6,'2026-07-06',NULL,NULL,'2026-07-06 16:12:29','2026-07-06 16:12:32'),(2,'APP-2026-2089',2,6,'2026-07-06',NULL,NULL,'2026-07-06 16:19:29','2026-07-06 16:19:32'),(3,'APP-2026-7204',3,6,'2026-07-06',NULL,NULL,'2026-07-06 16:20:56','2026-07-06 16:20:59'),(4,'APP-2026-1754',4,1,'2026-07-06',1,NULL,'2026-07-06 16:35:32','2026-07-06 16:35:37');
/*!40000 ALTER TABLE `id_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `national_ids`
--

DROP TABLE IF EXISTS `national_ids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `national_ids` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_number` varchar(20) NOT NULL,
  `citizen_id` bigint(20) unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `status` enum('active','expired','revoked') NOT NULL DEFAULT 'active',
  `issued_by` int(10) unsigned DEFAULT NULL,
  `card_printed_at` timestamp NULL DEFAULT NULL,
  `collected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_nid_number` (`id_number`),
  UNIQUE KEY `uq_nid_citizen` (`citizen_id`),
  KEY `idx_nid_expiry` (`expiry_date`),
  KEY `idx_nid_status` (`status`),
  KEY `fk_nid_issued_by` (`issued_by`),
  CONSTRAINT `fk_nid_citizen` FOREIGN KEY (`citizen_id`) REFERENCES `citizens` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_nid_issued_by` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `national_ids`
--

LOCK TABLES `national_ids` WRITE;
/*!40000 ALTER TABLE `national_ids` DISABLE KEYS */;
INSERT INTO `national_ids` VALUES (1,'NID-2026-3230',1,'2026-07-06','2036-07-06','active',2,'2026-07-06 16:12:32',NULL,'2026-07-06 16:12:32','2026-07-06 16:12:32'),(2,'NID-2026-5726',2,'2026-07-06','2036-07-06','active',2,'2026-07-06 16:19:32',NULL,'2026-07-06 16:19:31','2026-07-06 16:19:32'),(3,'NID-2026-3263',3,'2026-07-06','2036-07-06','active',2,'2026-07-06 16:20:59',NULL,'2026-07-06 16:20:58','2026-07-06 16:20:59');
/*!40000 ALTER TABLE `national_ids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` varchar(255) NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'info',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notif_user_read` (`user_id`,`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_name` (`name`),
  KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'citizens.view','Citizens','View citizen records','2026-07-07 03:57:00'),(2,'citizens.manage','Citizens','Create, edit, and delete citizen records','2026-07-07 03:57:00'),(3,'birth_certificates.view','Birth Certificates','View birth certificates','2026-07-07 03:57:00'),(4,'birth_certificates.manage','Birth Certificates','Register, edit, and revoke birth certificates','2026-07-07 03:57:00'),(5,'national_ids.view','National ID','View National ID cards','2026-07-07 03:57:00'),(6,'national_ids.manage','National ID','Mark National ID cards as collected','2026-07-07 03:57:00'),(7,'applications.view','Applications','View ID applications','2026-07-07 03:57:00'),(8,'applications.manage','Applications','Submit applications and change their status','2026-07-07 03:57:00'),(9,'reports.view','Reports','View and export reports','2026-07-07 03:57:00'),(10,'users.view','Users','View user accounts','2026-07-07 03:57:00'),(11,'users.manage','Users','Create, edit, delete, and reassign user accounts','2026-07-07 03:57:00'),(12,'roles.manage','Roles','Manage roles and their permission grants','2026-07-07 03:57:00'),(13,'settings.manage','Settings','Manage system settings','2026-07-07 03:57:00'),(14,'activity_logs.view','Audit','View the system activity log','2026-07-07 03:57:00');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remember_tokens`
--

DROP TABLE IF EXISTS `remember_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remember_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `selector` char(24) NOT NULL,
  `validator_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_remember_selector` (`selector`),
  KEY `idx_remember_user` (`user_id`),
  KEY `idx_remember_expires` (`expires_at`),
  CONSTRAINT `fk_remember_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remember_tokens`
--

LOCK TABLES `remember_tokens` WRITE;
/*!40000 ALTER TABLE `remember_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `remember_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_type` varchar(50) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`filters`)),
  `file_path` varchar(255) DEFAULT NULL,
  `generated_by` int(10) unsigned DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_reports_type_date` (`report_type`,`generated_at`),
  KEY `fk_reports_generated_by` (`generated_by`),
  CONSTRAINT `fk_reports_generated_by` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,'applications','2026-01-01','2026-07-07','{\"gender\":\"\",\"status\":\"\"}','applications_20260707_070139.csv',1,'2026-07-07 04:01:39'),(2,'applications','2026-01-01','2026-07-07','{\"gender\":\"\",\"status\":\"\"}','applications_20260707_070554.csv',1,'2026-07-07 04:05:54'),(3,'applications','2026-07-01','2026-07-07','{\"gender\":\"\",\"status\":\"\"}',NULL,1,'2026-07-07 04:05:54');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_rp_permission` (`permission_id`),
  CONSTRAINT `fk_rp_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,'2026-07-07 03:57:00'),(1,2,'2026-07-07 03:57:00'),(1,3,'2026-07-07 03:57:00'),(1,4,'2026-07-07 03:57:00'),(1,5,'2026-07-07 03:57:00'),(1,6,'2026-07-07 03:57:00'),(1,7,'2026-07-07 03:57:00'),(1,8,'2026-07-07 03:57:00'),(1,9,'2026-07-07 03:57:00'),(1,10,'2026-07-07 03:57:00'),(1,11,'2026-07-07 03:57:00'),(1,12,'2026-07-07 03:57:00'),(1,13,'2026-07-07 03:57:00'),(1,14,'2026-07-07 03:57:00'),(2,1,'2026-07-07 03:57:01'),(2,2,'2026-07-07 03:57:01'),(2,3,'2026-07-07 03:57:01'),(2,4,'2026-07-07 03:57:01'),(2,5,'2026-07-07 03:57:01'),(2,6,'2026-07-07 03:57:01'),(2,7,'2026-07-07 03:57:01'),(2,8,'2026-07-07 03:57:01'),(2,9,'2026-07-07 03:57:01'),(3,1,'2026-07-07 03:57:01'),(3,3,'2026-07-07 03:57:01'),(3,5,'2026-07-07 03:57:01'),(3,7,'2026-07-07 03:57:01'),(3,9,'2026-07-07 03:57:01'),(4,1,'2026-07-07 04:01:38'),(4,14,'2026-07-07 04:01:38'),(5,1,'2026-07-07 04:05:52'),(5,14,'2026-07-07 04:05:52');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','Full system access, including user management and settings.','2026-07-06 16:09:45','2026-07-06 16:09:45'),(2,'Officer','Registers and processes citizens, certificates, and applications.','2026-07-06 16:09:45','2026-07-06 16:09:45'),(3,'Viewer','Read-only access to records and reports.','2026-07-06 16:09:45','2026-07-06 16:09:45'),(4,'Auditor Reviewer','Read-only audit access','2026-07-07 04:01:38','2026-07-07 04:01:38'),(5,'Auditor Gamma','Read-only audit access','2026-07-07 04:05:52','2026-07-07 04:05:52');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_group` varchar(50) NOT NULL DEFAULT 'general',
  `updated_by` int(10) unsigned DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`),
  KEY `fk_settings_updated_by` (`updated_by`),
  CONSTRAINT `fk_settings_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'system_name','Somaliland Civil Registry','general',1,'2026-07-07 04:01:38'),(2,'office_address','Hargeisa, Somaliland','general',1,'2026-07-07 04:01:38'),(3,'contact_phone','+252634000000','general',1,'2026-07-07 04:01:38'),(4,'contact_email','info@civilregistry.gov','general',1,'2026-07-07 04:01:38'),(5,'email_from_name','','general',1,'2026-07-07 04:01:39'),(6,'email_from_address','','general',1,'2026-07-07 04:01:39'),(7,'theme_color','forest','general',1,'2026-07-07 04:01:39'),(8,'system_logo','','general',1,'2026-07-07 04:01:39');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'System Administrator','admin@civilregistry.gov','admin','$2y$10$11UTMHRMKFhY9e/ZqdTbGeJROYrhmG75cX.DvrxMMpcaWCWul5y1S',NULL,NULL,'active','2026-07-07 04:56:00','2026-07-06 16:11:14','2026-07-07 04:56:00',NULL),(2,2,'Registry Officer','officer@civilregistry.gov','officer','$2y$10$en.ZuuaKOEtW18iRpeWUd.R9pNSpJYVWM2xgdJOs2F2V1gSGqVvbG',NULL,NULL,'active','2026-07-06 16:20:55','2026-07-06 16:11:14','2026-07-06 16:20:55',NULL),(3,3,'Records Viewer','viewer@civilregistry.gov','viewer','$2y$10$xKKl2jbI5JTe8dPjHVfKcuCb1KD4u.qHnhBz9xvY1.KUWBPFo3kg.',NULL,NULL,'active','2026-07-07 04:37:14','2026-07-06 16:11:14','2026-07-07 04:37:14',NULL),(4,2,'Test Officer','testofficer761562@example.com','testofficer761562','$2y$10$g1l0hl.FPbYszArPCzA22eWhA/8tCSxs5k.C.N0I7oiPwcBJ6f4Ry','6300000562',NULL,'active',NULL,'2026-07-07 03:59:21','2026-07-07 03:59:24',NULL),(5,2,'Test Officer','testofficer895254@example.com','testofficer895254','$2y$10$l93NsEpwEGE6vFNxDN5vduZHVvQJ0Ig5iXP44ChdWagH5RpEg.dCC','6300000254',NULL,'active',NULL,'2026-07-07 04:01:35','2026-07-07 04:01:37',NULL),(6,2,'Test Officer','testofficer061758@example.com','testofficer061758','$2y$10$jYAmUcyXV430VAvMR/6uNuGWj3s2jRTttkVHCPGWvt5D8EnTNqiSa','6300000758',NULL,'active',NULL,'2026-07-07 04:04:21','2026-07-07 04:04:23',NULL),(7,2,'Test Officer','testofficer150055@example.com','testofficer150055','$2y$10$TO0EXkMi8947nYl.QwaU4OKyLtTTLSbNOVxEVF5/PmfslRzpDu4wm','6300000055',NULL,'active',NULL,'2026-07-07 04:05:50','2026-07-07 04:05:52',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'civil_registry_portal'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-07  7:58:17
